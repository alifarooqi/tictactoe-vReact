A Pen created at CodePen.io. You can find this one at https://codepen.io/ali-farooqi/pen/RZgExb.

 Known Bugs (v1):
-None

iMac  CSS Code Credits: http://purecssapple.com/